/** Automatically generated file. DO NOT MODIFY */
package tw.edu.vnu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}